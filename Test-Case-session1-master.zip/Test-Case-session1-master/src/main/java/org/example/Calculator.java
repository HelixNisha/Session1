package org.example;

public class Calculator {

    public static int add(int a, int b){
        int sum = a+b;
        return sum;
    }
}
